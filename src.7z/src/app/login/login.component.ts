import { Component } from '@angular/core';
import { Credentials } from './shared/credentials';
import { RegisterService } from './shared/signup.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
   title = 'sig';

   //userName: String = "";

    details:Credentials = new Credentials();

    constructor( private router private signup:RegisterService){}

    ngonInit() : void{}

    userRegister(){
      console.log(this.details);
      this.signup.registerUser(this.details).subscribe({
        next: (data) => alert("SignUp Successfull"), this.router.navigate(["login"])
        error: (err) => alert("Signup not Successful")          
        }
     );
}


}
