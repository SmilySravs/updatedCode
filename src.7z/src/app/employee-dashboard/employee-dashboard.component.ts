import { Component, OnInit } from '@angular/core';
import {FormBuilder,FormGroup} from '@angular/forms'
import { ApiService } from '../shared/api.service';
import { EmployeeModel } from './employee-dash board.model';


@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {

  formValue !: FormGroup;
  employeeModelObj : EmployeeModel = new EmployeeModel();
  employeeData !: any;
  showAdd!: boolean;
  showUpdate!: boolean;
  
  constructor(private formbuilder: FormBuilder, private api: ApiService ) { }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      id : [''],
      User_name : [''],
      User_type : [''],
      Max_age : [''],
      Primary_location_id : [''],
      Emailid_group : [''],
      Project_name : [''] 
    })
    this.getAllEmployee();
  }
clickAddEmployee(){
  this.formValue.reset();
  this.showAdd =true;
  this.showUpdate =false;
}
postEmployeeDetails(){
  this.employeeModelObj.User_name = this.formValue.value.User_name;
  this.employeeModelObj.User_type = this.formValue.value.User_type;
  this.employeeModelObj.Max_age = this.formValue.value.Max_age;
  this.employeeModelObj.Primary_location_id = this.formValue.value.Primary_location_id;
  this.employeeModelObj.Emailid_group = this.formValue.value.Emailid_group;
  this.employeeModelObj.Project_name = this.formValue.value.Project_name;


  this.api.postEmployee(this.employeeModelObj)
  .subscribe((res: any)=>{
    console.log(res);
    alert("Employee added successfully")
    let ref = document.getElementById('cancel')
    ref?.click();
    this.formValue.reset();
    this.getAllEmployee();
  },
    (    Error: any)=>{
    alert("something went wrong")
  })
}
getAllEmployee(){
  this.api.getEmployee()
  .subscribe(res=>{
    console.log(res)
    this.employeeData =res;
  })
}
deleteEmployee(row : any){
  this.api.deleteEmployee(row)
  .subscribe(res=>{
    alert("Employee deleted");
    
    //this.employeeData.splice(row,1)
  })
  this.getAllEmployee();
}

 onEdit(row: any){
  this.showAdd =false;
  this.showUpdate =true;
  this.employeeModelObj.id =row;
  this.formValue.controls['User_name'].setValue(row.User_name);
  this.formValue.controls['User_type'].setValue(row.User_type);
  this.formValue.controls['Max_age'].setValue(row.Max_age);
  this.formValue.controls['Primary_location_id'].setValue(row.Primary_location_id);
  this.formValue.controls['Emailid_group'].setValue(row.Emailid_group);
  this.formValue.controls['Project_name'].setValue(row.Project_name);
 }
 updateEmployeeDetails(){
  this.employeeModelObj.User_name = this.formValue.value.User_name;
  this.employeeModelObj.User_type = this.formValue.value.User_type;
  this.employeeModelObj.Max_age = this.formValue.value.Max_age;
  this.employeeModelObj.Primary_location_id = this.formValue.value.Primary_location_id;
  this.employeeModelObj.Emailid_group = this.formValue.value.Emailid_group;
  this.employeeModelObj.Project_name = this.formValue.value.Project_name;
  this.api.updateEmployee(this.employeeModelObj,this.employeeModelObj.id)
  .subscribe(res=>{
    alert("updated sucessfully")
    let ref = document.getElementById('cancel')
    ref?.click();
    this.formValue.reset();
    this.getAllEmployee();
  })
 }
}
