export class EmployeeModel{
    id : number =0;
    User_name :  string = '';
    User_type : string = '';
    Max_age : number = 0;
    Primary_location_id : number = 0;
    Emailid_group : string = '';
    Project_name : string = '';

}