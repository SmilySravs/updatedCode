export class Credentials {
    userName!: String;
    userId!:String;
    password!:String;
    confirmPassword!:String;
    email!:String;
    projectName!:String;
}

