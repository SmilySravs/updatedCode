import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { Credentials } from './credentials';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {
   baseUrl="http://localhost:8080/login";
  constructor(private httpClient: HttpClient) { }


  registerUser(details: Credentials): Observable<Object> {
     console.log(details);
     return this.httpClient.post(`${this.baseUrl}/register`,details);
  }
}