import { Component } from '@angular/core';
import { Credentials } from './shared/credentials';
import { RegisterService } from './shared/signup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
   title = 'sig';

   //userName: String = "";

    details:Credentials = new Credentials();

    constructor(private signup:RegisterService){}

    ngonInit() : void{}

    userRegister(){
      console.log(this.details);
      this.signup.registerUser(this.details).subscribe({
        next: (data) => alert("SignUp Successfull"),
        error: (err) => alert("Signup not Successful")          
        }
     );
}


}
